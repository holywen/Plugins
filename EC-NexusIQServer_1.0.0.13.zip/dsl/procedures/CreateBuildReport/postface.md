### Create Build Report

To Create Build Report in Flow interface, do these steps:

 * Create Pipeline.
 * Create task.
 * In task definition choose Plugin and choose following parameters:
   <br /><img src="../../plugins/EC-NexusIQServer/images/CreateBuildReport/PipelinePicker.png" />
 * Click on arrow.
 * Enter the following parameters:
   <br /><img src="../../plugins/EC-NexusIQServer/images/CreateBuildReport/PipelineConfig.png" />

After the pipeline runs, you can view the results, including the following step details:
<br /><img src="../../plugins/EC-NexusIQServer/images/CreateBuildReport/PipelineResult.png" />
<br />In the <b>CreateBuildReport</b> step, click the Log icon to see the diagnostic information. The output is similar to the following diagnostic report.
<br /><img src="../../plugins/EC-NexusIQServer/images/CreateBuildReport/PipelineLog.png" />

#### Procedure Output Parameters

<table class="grid">
<thead>
<tr>
<th>Output Parameter (Electric Flow 8.3+)</th><th>Description</th>
</tr>
</thead>

<tr>
<td>Violation Summary</td>
<td>Something like this "Summary of policy violations: 7 critical, 3 severe, 0 moderate"</td>
</tr>

<tr>
<td>Build Report URL</td>
<td>Path to Build Report URL. Something like this http://nexus/ui/links/application/sandbox-application/report/806fbab9e4ed426e85e1a7ee721b0e6f</td>
</tr>

<tr>
<td>Critical Violation Count</td>
<td>Number of Critical Violations, for example 7</td>
</tr>

<tr>
<td>Severe Violation Count</td>
<td>Number of Severe Violations, for example 3</td>
</tr>

<tr>
<td>Moderate Violation Count</td>
<td>Number of Moderate of Violations, for example 0</td>
</tr>

<tr>
<td>Component Count </td>
<td>Number of Components Identified, for example 28</td>
</tr>

<tr>
<td>Security Issue Count</td>
<td>Number of Security Issues Identified, for example 27</td>
</tr>

<tr>
<td>License Issue Count</td>
<td>Number of License Issues Identified, for example 6</td>
</tr>

</table>

