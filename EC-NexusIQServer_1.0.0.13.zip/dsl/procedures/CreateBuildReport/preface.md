This procedure creates Nexus IQ Server Build Report.
