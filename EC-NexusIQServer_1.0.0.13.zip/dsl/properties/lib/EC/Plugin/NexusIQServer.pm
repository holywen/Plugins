
# Copyright 2016 Electric Cloud, Inc.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


package EC::Plugin::NexusIQServer;

use strict;
use warnings;
use Data::Dumper;
use JSON;
use base qw(EC::Plugin::Core);
use File::Path;
use LWP::UserAgent;
use HTTP::Request;

=head2 after_init_hook

Debug level - we are reading property /projects/EC-PluginName-1.0.0/debugLevel.
If this property exists, it will set the debug level. Otherwize debug level will be 0, which is info.

=cut

sub after_init_hook {
    my ($self, %params) = @_;

    $self->{plugin_name} = 'EC-NexusIQServer-1.0.0.13';
    $self->{plugin_key} = 'EC-NexusIQServer';
    my $debug_level = 0;
    my $proxy;

    $self->logger->info($self->{plugin_name});

    if ($self->{plugin_key}) {
        eval {
            $debug_level = $self->ec()->getProperty(
                "/plugins/$self->{plugin_key}/project/debugLevel"
            )->findvalue('//value')->string_value();
        };
    }

    $self->{ec} = ElectricCommander->new();
    if ($debug_level) {
        $self->debug_level($debug_level);
        $self->logger->level($debug_level);
        $self->logger->debug("Debug enabled for $self->{plugin_key}");
    }
    else {
        $self->debug_level(0);
    }
}


sub step_create_build_report {
    my ($self) = @_;

    my $params = $self->get_params_as_hashref(qw|
        config
        nexusApplicationId
        nexusApplicationWarLocation
    |);

    my $config = $self->get_config();

    my $command = $self->gen_cmd($params);

    my $safe_command = $command;
    my $regexp = quotemeta($config->{password});
    $safe_command =~ s/(?:$regexp)/***/gs;
    print "Executing $safe_command\n";

    my $cmd_res = `$command`;
    my $exit_code = $? >> 8;

    # $self->set_output_parameter('jiraids', $jira_ids_string);
    # Violation Summary
    # Build Report URL
    $self->log()->info("Command exited with code: $exit_code");
    my $message = '';
    if ($exit_code) {
        $message = 'Error occured during Build Report Creation.';
    }
    $self->log()->info("Command execution result:\n$cmd_res");
    my $retval = $self->extract_values($cmd_res);
    if ($retval->{url}) {
        $self->set_output_parameter('Build Report URL', $retval->{url});
    }
    if ($retval->{violations}) {
        $self->set_output_parameter('Violation Summary', $retval->{violations});
        # let's set detailed params.
        my $v = $retval->{violations};

        for my $m (qw/critical moderate severe/) {
            if ($v =~ m/(\d+)\s*$m/s) {
                # opt = output param
                my $opt = ucfirst($m) . ' Violation Count';
                $self->set_output_parameter($opt, $1);
            }
        }
    }
    my $set_result = {
        outcome => {
            target => 'myCall',
            result => $exit_code ? 'error' : 'success',
        },
        procedure => {
            target => 'myCall',
            msg => ''
        },
        pipeline => {
            target => 'Nexus IQ Server Created Build Report:',
            msg => '',
        }
    };
    if (!$exit_code && $retval->{url} && $retval->{violations}) {
        # $set_result->{pipeline}->{msg} = $message2;
        # $set_result->{procedure}->{msg} = $message;

        # Ok, it is time to retrieve full report.
        # nexusApplicationId
        my $summary_params = {
            url        => $retval->{url},
            violations => $retval->{violations},
            components => 0,
            security   => 0,
            license    => 0
        };
        my $report_url_template = 'applications/%s/reports/%s';
        if ($retval->{url} =~ m/^http.*?report\/(.*?)$/s) {
            my $report_url = sprintf($report_url_template, $params->{nexusApplicationId}, $1);
            my $report = $self->get_report_details($report_url);
            if ($report) {
                my $report_details = $self->parse_nexus_report($report);
                if ($report_details->{componentsIdentifiedCount}) {
                    $summary_params->{components} = $report_details->{componentsIdentifiedCount};
                    $self->set_output_parameter('Component Count', $report_details->{componentsIdentifiedCount});
                }
                if ($report_details->{licenseIssueCount}) {
                    $summary_params->{license} = $report_details->{licenseIssueCount};
                    $self->set_output_parameter('License Issue Count', $report_details->{licenseIssueCount});
                }
                if ($report_details->{securityIssueCount}) {
                    $summary_params->{security} = $report_details->{securityIssueCount};
                    $self->set_output_parameter('Security Issue Count', $report_details->{securityIssueCount});
                }
            }
        }
        my $html_summary = $self->gen_html_report(%$summary_params);
        $set_result->{pipeline}->{msg} = $html_summary->{pipeline};
        $set_result->{procedure}->{msg} = $html_summary->{procedure};
    }
    my $exit = $self->set_result(%$set_result);

    unless ($exit_code) {
        $self->log()->info("Violations: $retval->{violations}");
        $self->log()->info("Report URL: $retval->{url}");
    }
    $exit->();
}

sub gen_html_report {
    my ($self, %params) = @_;

    my $t = q|Components found: %s <br />
Policy Alerts: %s
Security Alerts: %s
License Alerts: %s
<br />
Build Report Location: <a target="_BLANK" href="%s">%s</a>
|;
    my $rendered = sprintf(
        $t,
        $params{components},
        $params{violations},
        $params{security},
        $params{license},
        $params{url}, $params{url},
    );

    my $retval = {
        procedure => qq|<html><span class="jobStep_statusText"><br />$rendered</span></html>|,
        pipeline  => qq|<html>$rendered</html>|,
    };
    return $retval;
}

sub extract_values {
    my ($self, $log) = @_;

    my $retval = {
        url => '',
        violations => '',
    };

    if ($log =~ m/Summary\sof\spolicy\sviolations:\s*(.*?)$/ms) {
        $retval->{violations} = $1;
    }

    if ($log =~ m|The\sdetailed\sreport\scan\sbe\sviewed\sonline at\s*(http:\/\/.*?)$|ms) {
        $retval->{url} = $1;
    }
    return $retval;
}


sub gen_cmd {
    my ($self, $params) = @_;

    # 1 - java path
    # 2 - client.jar
    # 3 - id
    # 4 - server url
    # 5 - credenrials username:password
    # 6 - app path
    my $cmd_template = q|%s -jar %s -i %s -s %s -a %s %s 2>&1|;

    my $cfg = $self->get_config();
    my $cmd = sprintf $cmd_template,
        $cfg->{nexusJavaLocation} || 'java',
        $self->esc_args($cfg->{nexusCLILocation}),
        $self->esc_args($params->{nexusApplicationId}),
        $self->esc_args($cfg->{nexusServerURL}),
        $self->esc_args(qq|$cfg->{userName}:$cfg->{password}|),
        $params->{nexusApplicationWarLocation}
        ;
    return $cmd;
}

sub get_config {
    my ($self) = @_;

    my $config_name = $self->get_param('config');

    unless($self->{config}->{$config_name}) {
        my $config = $self->get_config_values($config_name);
        $self->{config}->{$config_name} = $config;
        if (my $debug_level = $self->{config}->{$config_name}->{debugLevel}) {
            $self->debug_level($debug_level);
            $self->logger->level($debug_level);
        }
        $self->logger->debug('Debug was enabled');
        $self->logger->trace('Trace was enabled');
    }
    return $self->{config}->{$config_name};
}


sub parse_nexus_report {
    my ($self, $obj) = @_;

    my $retval = {
        componentsIdentifiedCount => 0,
        licenseIssueCount => 0,
        securityIssueCount => 0,
    };
    if ($obj->{matchSummary}) {
        $retval->{componentsIdentifiedCount} = $obj->{matchSummary}->{totalComponentCount};
    }

    for my $row (@{$obj->{components}}) {
        if ($row->{licenseData}->{effectiveLicenseThreats}) {
            for my $l (@{$row->{licenseData}->{effectiveLicenseThreats}}) {
                if ($l->{licenseThreatGroupCategory} ne 'no-threat') {
                    $retval->{licenseIssueCount}++;
                }
            }
        }
        if ($row->{securityData}->{securityIssues}) {
            $retval->{securityIssueCount} += scalar @{$row->{securityData}->{securityIssues}};
        }
    }
    return $retval;
}


sub rest_call {
    my ($self, $method, $url, $params) = @_;

    my $cfg = $self->get_config();
    my $full_url = $cfg->{nexusServerURL};
    $full_url =~ s|\/$||gs;
    $full_url .= '/api/v2/' . $url;

    $self->logger()->info("Full url: $full_url");
    my $req = HTTP::Request->new($method => $full_url);
    $req->header('Accept' => 'application/json');
    $req->header('Content-Type' => 'application/json');

    $req->authorization_basic($cfg->{userName}, $cfg->{password});
    my $ua = LWP::UserAgent->new();
    my $resp = $ua->request($req);

    return $resp;
}


sub get_report_details {
    my ($self, $report_location) = @_;

    my $retval = $self->rest_call(GET => $report_location);
    return decode_json($retval->decoded_content);
    # if ($retval->code() > 199 && $retval->code() < 400) {
    # }
}

1;
